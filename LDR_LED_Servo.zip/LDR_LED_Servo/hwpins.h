/*  \file	hwpins.h
 *  \brief	This is the header to define the pins and macros.
 *
 *  Created on: 9 July 2021
 *      Author:
 */

#ifndef HWPINS_H_
#define HWPINS_H_

//User configuration for Arduino PIN number
//#define DETECT 			(A0)
//#define LIGHT			(2)

#define LDR_WEST   (A0)
#define LDR_EAST   (A1)

#define LED_WEST   (2)
#define LED_EAST   (4)

#define SERVO_WEST  (5)
#define SERVO_EAST  (6)

#define SERVO_0     (750)   // 0 degree (contract)
#define SERVO_180   (2250)  // 180 degree (expand)



#endif /* HWPINS_H_ */
