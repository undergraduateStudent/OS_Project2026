/* ###*B*###
 * Erika Enterprise, version 3
 *
 * Copyright (C) 2017 - 2019 Evidence s.r.l.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License, version 2, for more details.
 *
 * You should have received a copy of the GNU General Public License,
 * version 2, along with this program; if not, see
 * <www.gnu.org/licenses/old-licenses/gpl-2.0.html >.
 *
 * This program is distributed to you subject to the following
 * clarifications and special exceptions to the GNU General Public
 * License, version 2.
 *
 * THIRD PARTIES' MATERIALS
 *
 * Certain materials included in this library are provided by third
 * parties under licenses other than the GNU General Public License. You
 * may only use, copy, link to, modify and redistribute this library
 * following the terms of license indicated below for third parties'
 * materials.
 *
 * In case you make modified versions of this library which still include
 * said third parties' materials, you are obligated to grant this special
 * exception.
 *
 * The complete list of Third party materials allowed with ERIKA
 * Enterprise version 3, together with the terms and conditions of each
 * license, is present in the file THIRDPARTY.TXT in the root of the
 * project.
 * ###*E*### */

/** \file	task.cpp
 *  \brief	User Tasks
 *
 *  This file contains the code of application task for Erika Enterprise.
 *
 *  \author Amos Lem Yu Kai (2401559)
 *  \date 27/03/2026
 */

/* ERIKA Enterprise. */
#include "ee.h"

/* Arduino SDK. */
#include "Arduino.h"

/* Local Headers */
#include "hwpins.h"
#include "ServoTimer2.h"
#include "LiquidCrystal.h"
#include "lcd.h"

LiquidCrystal lcd(RS, EN, D4, D5, D6, D7);

extern "C" {

/* External Functions */
extern void serial_print(char const * msg);

/* TASKs Declarations */
DeclareTask(DetectLight);

ServoTimer2 servoWest;
ServoTimer2 servoEast;

/* =========================
   CONFIGURATION
========================= */

// Night threshold (Lux)
#define NIGHT_THRESHOLD     (200)

// Day threshold (Lux)
#define DAY_THRESHOLD (500)

// ADC + LDR constants
#define MAX_ADC_READING     (1023)
#define ADC_REF_VOLTAGE     (5.0)
#define REF_RESISTANCE      (5000)
#define LUX_CALC_SCALAR     (889985.88)
#define LUX_CALC_EXPONENT   (-1.16552)

float luxWest = 0;
float luxEast = 0;

int hour = 18;     // start time (for testing)
int minute = 29;
int second = 0;

void updateClock()
{
    second++;

    if (second >= 60) {
        second = 0;
        minute++;
    }

    if (minute >= 60) {
        minute = 0;
        hour++;
    }

    if (hour >= 24) {
        hour = 0;
    }
}

bool isNightTime()
{
    if ((hour > 18 || (hour == 18 && minute >= 30)) ||
        (hour < 7 || (hour == 7 && minute <= 30)))
    {
        return true;
    }
    return false;
}

/*************************************************************
 *  \Function    DetectLight
 *  \brief       Reads 2 LDR sensors and controls LEDs
 *               independently for West and East zones
 *               Runs every 500ms (configured in OIL)
 *************************************************************/
TASK(DetectLight)
{
	static int tick = 0;
	tick++;

	if (tick >= 2) {   // 2 cycles = 1 second (since task = 500ms)
	    tick = 0;
	    updateClock();
	}

	float resistorVoltage, ldrVoltage, ldrResistance;

    /* WEST */
    int rawWest = analogRead(LDR_WEST);
    if (rawWest == 0) rawWest = 1;

    resistorVoltage = (float) rawWest / MAX_ADC_READING * ADC_REF_VOLTAGE;
    ldrVoltage = ADC_REF_VOLTAGE - resistorVoltage;
    ldrResistance = ldrVoltage / resistorVoltage * REF_RESISTANCE;
    luxWest = LUX_CALC_SCALAR * pow(ldrResistance, LUX_CALC_EXPONENT);

    /* EAST */
    int rawEast = analogRead(LDR_EAST);
    if (rawEast == 0) rawEast = 1;

    resistorVoltage = (float) rawEast / MAX_ADC_READING * ADC_REF_VOLTAGE;
    ldrVoltage = ADC_REF_VOLTAGE - resistorVoltage;
    ldrResistance = ldrVoltage / resistorVoltage * REF_RESISTANCE;
    luxEast = LUX_CALC_SCALAR * pow(ldrResistance, LUX_CALC_EXPONENT);

    Serial.print("West: ");
    Serial.print(luxWest);
    Serial.print(" East: ");
    Serial.println(luxEast);

    /* LED */
    //digitalWrite(LED_WEST, (luxWest <= NIGHT_THRESHOLD));
    //digitalWrite(LED_EAST, (luxEast <= NIGHT_THRESHOLD));

    /* =========================
       STREETLIGHT WITH PRIORITY
    ========================= */
    if (isNightTime())
    {
        // FORCE ON regardless of lux
        digitalWrite(LED_WEST, HIGH);
        digitalWrite(LED_EAST, HIGH);
    }
    else
    {
        // Normal LDR logic (daytime only)
        digitalWrite(LED_WEST, (luxWest <= NIGHT_THRESHOLD));
        digitalWrite(LED_EAST, (luxEast <= NIGHT_THRESHOLD));
    }

    /* SERVO */
    servoWest.write(luxWest >= DAY_THRESHOLD ? SERVO_180 : SERVO_0);
    servoEast.write(luxEast >= DAY_THRESHOLD ? SERVO_180 : SERVO_0);

    /* ROW 0: WEST */
    lcd.setCursor(0, 0);
    lcd.print("West:           ");
    lcd.setCursor(6, 0);
    lcd.print(luxWest, 1);

    /* ROW 1: EAST */
    lcd.setCursor(0, 1);
    lcd.print("East:           ");
    lcd.setCursor(6, 1);
    lcd.print(luxEast, 1);

    /* ROW 2: LED STATUS */
    /* ROW 2: LED + SHADE STATUS */
    lcd.setCursor(0, 2);
    lcd.print("W:");
    lcd.print(luxWest <= NIGHT_THRESHOLD ? "ON " : "OFF");

    lcd.print(" S:");
    lcd.print(luxWest >= DAY_THRESHOLD ? "O " : "C ");

    lcd.setCursor(11, 2);   // shift EAST to avoid overlap
    lcd.print("E:");
    lcd.print(luxEast <= NIGHT_THRESHOLD ? "ON " : "OFF");

    lcd.print(" S:");
    lcd.print(luxEast >= DAY_THRESHOLD ? "O" : "C");

    /* ROW 3: TIME ONLY */
    lcd.setCursor(0, 3);
    lcd.print("Time:           ");
    lcd.setCursor(6, 3);

    if (hour < 10) lcd.print("0");
    lcd.print(hour);
    lcd.print(":");

    if (minute < 10) lcd.print("0");
    lcd.print(minute);
    lcd.print(":");

    if (second < 10) lcd.print("0");
    lcd.print(second);

    TerminateTask();
}

}   /* extern "C" */

